<?php 

//connexion à la bdd
try{
	$db= new PDO(
		'mysql:host=localhost;dbname=crud;','root','');}
	catch(Exception $e){
	die('Erreur: '.$e->getMessage());
}

//Créer des nouveles données 

     
    if(isset($_POST) && !empty($_POST)){

        $Nom = $_POST["Nom"];
        $Couriel = $_POST["Couriel"];
        $Message = $_POST["Message"];  }


        $response = $db->prepare('INSERT INTO client (Nom, Couriel, Message) VALUES (:Nom,:Couriel,:Message)');
        $response->execute([
                "Nom" => $Nom,
                "Couriel" => $Couriel,
                "Message" => $Message
        ]);
        $response->closeCursor();


//afficher les données
$response = $db->query('SELECT Nom, Couriel, Message, id FROM client');

$data = $response->fetchall();
var_dump($data);

$response->closecursor();



//mettre à jour les données 
            if(isset($_GET) && !empty($_GET)){
        $id = $_GET["id"];
        $response = $db->prepare('SELECT * FROM client WHERE id= :id');
        $response->execute(["id" => $id]);

        $client = $response->fetch();

        $response->closeCursor();

        if($client === false){
            header('Location: Final html.html');
            exit();
        }

    }else{
        header('Location: Final html.html');
        exit();
    }


//effacer les données 

        $response = $db->prepare('DELETE FROM client WHERE id = :id');
    $response->execute(["id" => $_GET["id"]]);

    $response->closeCursor();

    header('Location: TP final html.html');
    exit();

?>


<!doctype html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>


    <form action="#" method="POST">

        <div>
            <label for="Nom">Nom</label><br/>
            <input type="text" name="Nom" id="Nom">
        </div>
<div>
            <label for="Couriel">Couriel</label><br/>
            <input type="text" name="Couriel" id="Couriel">
        </div>

        <div>
            <label for="Message">message</label><br/>
            <textarea name="text" id="Message" cols="30" rows="10"></textarea>
        </div>

        <div>
                <?php

                    foreach($categories as $c){
                        echo "<option value='".$c["id"]."'>".$c["Nom"]."</option>";
                    }

                ?>

        </div>

        <div>
            <button>Enregistrer</button>
        </div>

    </form>



</body>
</html>

<!doctype html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>


<form action="#" method="POST">

    <div>
        <label for="Nom">Nom</label><br/>
        <input type="text" name="Nom" id="Nom" value="<?php echo $client["Nom"];  ?>">
    </div>

    <div>
        <label for="Message">Message</label><br/>
        <textarea name="Message" id="Message" cols="30" rows="10"><?php echo $client["Message"]; ?></textarea>
    </div>

    <div>
        <label for="Couriel">Couriel</label>
        <select type="text" name="Couriel" id="Couriel">
            <?php

            foreach($categories as $c){

                if($c["id"] == $client["category_id"]){
                    echo "<option value='".$c["id"]."' selected>".$c["Nom"]."</option>";
                }else{
                    echo "<option value='".$c["id"]."'>".$c["Nom"]."</option>";
                }
            }

            ?>

        </select>
    </div>

    <div>
        <input type="hidden" name="id" value="<?php echo $client["id"]; ?>">
        <button>Enregistrer</button>
    </div>

</form>



</body>
</html>